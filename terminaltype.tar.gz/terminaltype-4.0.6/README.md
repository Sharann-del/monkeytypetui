# monkeytypetui
Terminal-based typing test inspired by MonkeyType, featuring real-time WPM and accuracy tracking, clean TUI design, and a fast, distraction-free experience built for developers who love the CLI.
